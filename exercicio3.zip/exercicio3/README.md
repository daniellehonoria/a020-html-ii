Altere o texto ```<p>``` do rodapé do arquivo index.html, adicionando a ele um link para a página sugestao.html.

Na página sugestão.html, crie um formulário na área indicada. O formulário deve possuir três inputs, cada um com seu **label**. Os campos a ser preenchidos devem ser:
- Nome
- e-mail
- Sugestão de clima

O formulário deve possuir um botão escrito enviar, de tipo "submit".